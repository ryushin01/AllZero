import { TabContainer } from "./TabContainer";

export { TabContainer };
