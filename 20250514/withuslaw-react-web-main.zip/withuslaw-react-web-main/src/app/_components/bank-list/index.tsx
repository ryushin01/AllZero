import { BankComponent } from "./BankComponent";
import BankList from "./BankList";

export { BankComponent, BankList };
