import React from "react";

export default function DuplicatePage() {
  return <h3>중복 로그인이야...</h3>;
}
